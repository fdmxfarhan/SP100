/* Define to prevent recursive inclusion **************************************/
#ifndef __NX7_ADC_ISR_H
#define __NX7_ADC_ISR_H

/* Includes *******************************************************************/
#include "nx7_atc_ccu.h"

/* Exported types *************************************************************/

/* Exported constants *********************************************************/

/* Exported macro *************************************************************/

/* Exported functions *********************************************************/
void NX7_ADC_Init(void);
void NX7_ADC_DeInit(void);

#endif
