/* Define to prevent recursive inclusion **************************************/
#ifndef __SP100_A2D_ISR_H
#define __SP100_A2D_ISR_H

/* Includes *******************************************************************/
#include "sp100_atc_ccu.h"

/* Exported types *************************************************************/

/* Exported constants *********************************************************/

/* Exported macro *************************************************************/

/* Exported functions *********************************************************/
void SP100_A2D_Init(void);
void SP100_A2D_DeInit(void);

#endif
